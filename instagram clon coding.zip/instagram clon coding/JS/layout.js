    
//Codes included inside $( document ).ready() will only run once the page
   $(document).ready(function () {
        renderStory()
        captionFirst()
        captionSecond()
        captionThird()
    });